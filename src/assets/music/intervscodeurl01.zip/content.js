// VSCode URL Interceptor Content Script
(function() {
    'use strict';

    // 检查是否已经加载过，避免重复加载
    if (window.vsCodeInterceptorLoaded) {
        console.log('🔄 VSCode URL Interceptor 已存在，跳过重复加载');
        return;
    }
    window.vsCodeInterceptorLoaded = true;

    console.log('🚀 VSCode URL Interceptor 已加载 - 时间:', new Date().toISOString());
    console.log('🌐 当前页面:', window.location.href);
    console.log('📄 文档状态:', document.readyState);

// 配置选项
let config = {
    enabled: true,
    showNotification: true,
    customPrefix: '>Developer: Open URL',
    interceptProtocols: ['vscode://', 'vscode-insiders://'],
    useOpenUrlCommand: true
};

// 从存储中加载配置（安全版本）
function loadConfig() {
    try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
            chrome.storage.sync.get(['config'], (result) => {
                if (chrome.runtime && chrome.runtime.lastError) {
                    console.log('VSCode URL Interceptor: 加载配置时出错:', chrome.runtime.lastError);
                    return;
                }
                if (result && result.config) {
                    config = { ...config, ...result.config };
                    console.log('VSCode URL Interceptor: 配置已加载', config);
                }
            });

            // 监听存储变化
            if (chrome.storage.onChanged) {
                chrome.storage.onChanged.addListener((changes, namespace) => {
                    if (namespace === 'sync' && changes.config) {
                        config = { ...config, ...changes.config.newValue };
                        console.log('VSCode URL Interceptor: 配置已更新', config);
                    }
                });
            }
        }
    } catch (error) {
        console.log('VSCode URL Interceptor: 无法访问chrome.storage API，使用默认配置:', error);
    }
}

// 安全地加载配置
loadConfig();

// 创建引导式通知弹窗
function createNotification(url, type = 'success') {
    // 移除已存在的通知
    const existingNotification = document.getElementById('vscode-interceptor-notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.id = 'vscode-interceptor-notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        z-index: 10000;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        min-width: 400px;
        max-width: 500px;
        border-left: 4px solid #007ACC;
        animation: slideIn 0.3s ease;
    `;

    notification.innerHTML = `
        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <span style="font-size: 24px; margin-right: 10px; color: #007ACC;">🔧</span>
            <h4 style="margin: 0; color: #333; font-weight: 600;">请手动到VS里登录</h4>
        </div>
        <div style="color: #666; margin-bottom: 20px; font-size: 14px;">
            AugmentCode认证链接已拦截，请按照以下步骤完成认证：
        </div>

        <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; border-left: 3px solid #007ACC; margin-bottom: 15px;">
            <div style="font-weight: 600; color: #007ACC; margin-bottom: 8px;">操作步骤</div>
            <div style="font-size: 13px; color: #333; margin-bottom: 15px;">
                VSCODE搜索框里面<span style="color: #dc3545; font-weight: bold;">手动输入</span>
                <code style="background: #e9ecef; padding: 2px 6px; border-radius: 3px; font-family: monospace;">>Developer: Open URL</code>
                ，然后回车，粘贴复制的链接
            </div>
            <button data-action="copy-auth-link" data-url="${url}"
                    style="background: #007ACC; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 14px; width: 100%; font-weight: 500; transition: all 0.3s ease;"
                    id="copyButtonNotification">
                📋 认证链接
            </button>
        </div>

        <div style="text-align: right;">
            <button data-action="close-notification"
                    style="background: none; border: none; color: #6c757d; cursor: pointer; font-size: 12px; padding: 5px 10px;">
                我知道了
            </button>
        </div>
    `;

    document.body.appendChild(notification);

    // 添加CSS动画
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
}

// 从通知中复制认证链接
function copyAuthLinkFromNotification(url) {
    const button = document.getElementById('copyButtonNotification');

    navigator.clipboard.writeText(url).then(() => {
        // 成功复制 - 快速闪烁绿色效果
        const originalBg = button.style.background;
        const originalText = button.textContent;

        button.style.background = '#28a745';
        button.textContent = '✅ 已复制';

        setTimeout(() => {
            button.style.background = originalBg;
            button.textContent = originalText;
        }, 800);

    }).catch(() => {
        // 复制失败 - 快速闪烁红色效果
        const originalBg = button.style.background;
        const originalText = button.textContent;

        button.style.background = '#dc3545';
        button.textContent = '❌ 复制失败';

        setTimeout(() => {
            button.style.background = originalBg;
            button.textContent = originalText;
        }, 800);
    });
}

// 使用事件委托处理通知中的按钮点击，避免全局函数污染
document.addEventListener('click', function(event) {
    const target = event.target;

    if (target.getAttribute('data-action') === 'copy-auth-link') {
        event.preventDefault();
        const url = target.getAttribute('data-url');
        copyAuthLinkFromNotification(url);
    } else if (target.getAttribute('data-action') === 'close-notification') {
        event.preventDefault();
        const notification = target.closest('#vscode-interceptor-notification');
        if (notification) {
            notification.remove();
        }
    }
});

// 检查扩展上下文是否有效
function isExtensionContextValid() {
    try {
        return chrome && chrome.runtime && chrome.runtime.id;
    } catch (error) {
        return false;
    }
}

// 复制到剪贴板
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (err) {
        console.error('复制失败:', err);
        // 降级方案
        try {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            const result = document.execCommand('copy');
            document.body.removeChild(textArea);
            return result;
        } catch (fallbackErr) {
            console.error('降级复制也失败:', fallbackErr);
            return false;
        }
    }
}

// 检查是否为目标协议链接
function isTargetProtocol(url) {
    return config.interceptProtocols.some(protocol => url.startsWith(protocol));
}

// 格式化VSCode命令
function formatVSCodeCommand(url) {
    // 直接返回纯链接，不添加任何前缀
    return url;
}

// 处理链接点击
async function handleLinkClick(event) {
    console.log('VSCode URL Interceptor: 检测到点击事件');

    // 检查扩展上下文是否有效
    if (!isExtensionContextValid()) {
        console.log('⚠️ VSCode URL Interceptor: 扩展上下文已失效，停止处理');
        return;
    }

    if (!config.enabled) {
        console.log('VSCode URL Interceptor: 插件已禁用');
        return;
    }

    const target = event.target.closest('a');
    if (!target) {
        console.log('VSCode URL Interceptor: 未找到链接元素');
        return;
    }

    if (!target.href) {
        console.log('VSCode URL Interceptor: 链接没有href属性');
        return;
    }

    console.log('VSCode URL Interceptor: 检查链接:', target.href);
    console.log('VSCode URL Interceptor: 支持的协议:', config.interceptProtocols);

    if (isTargetProtocol(target.href)) {
        console.log('VSCode URL Interceptor: 匹配到目标协议，开始拦截');
        event.preventDefault();
        event.stopPropagation();

        const formattedCommand = formatVSCodeCommand(target.href);
        console.log('拦截到协议链接:', target.href);
        console.log('格式化命令:', formattedCommand);

        const success = await copyToClipboard(formattedCommand);

        if (config.showNotification) {
            if (success) {
                createNotification(target.href, 'success');
            } else {
                createNotification(target.href, 'error');
            }
        }

        // 发送统计信息到后台（完全可选，不影响主要功能）
        setTimeout(() => {
            try {
                if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.id) {
                    chrome.runtime.sendMessage({
                        type: 'URL_INTERCEPTED',
                        url: target.href,
                        formatted: formattedCommand,
                        success: success
                    }, () => {
                        // 忽略响应，避免错误
                        if (chrome.runtime.lastError) {
                            // 静默处理错误
                        }
                    });
                }
            } catch (error) {
                // 静默处理错误，不影响主要功能
            }
        }, 0);
    } else {
        console.log('VSCode URL Interceptor: 链接不匹配目标协议，跳过拦截');
    }
}

// 全局点击调试监听器
function debugClickListener(event) {
    console.log('🖱️ 检测到点击事件:', {
        target: event.target,
        tagName: event.target.tagName,
        className: event.target.className,
        id: event.target.id
    });

    const link = event.target.closest('a');
    if (link) {
        console.log('🔗 点击的是链接:', {
            href: link.href,
            text: link.textContent.trim(),
            outerHTML: link.outerHTML.substring(0, 200) + '...'
        });

        if (link.href && (link.href.startsWith('vscode://') || link.href.startsWith('vscode-insiders://'))) {
            console.log('🎯 发现VSCode协议链接!', link.href);
        }
    }
}

// 安全地注册事件监听器
function registerEventListeners() {
    // 添加调试点击监听器
    document.addEventListener('click', debugClickListener, true);

    // 监听点击事件
    document.addEventListener('click', handleLinkClick, true);

    // 监听右键菜单（可能的复制操作）
    document.addEventListener('contextmenu', function(event) {
        const target = event.target.closest('a');
        if (target && target.href && isTargetProtocol(target.href)) {
            // 可以在这里添加右键菜单的处理逻辑
            console.log('右键点击协议链接:', target.href);
        }
    });

    // 监听键盘事件（Ctrl+点击等）
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey || event.metaKey) {
            // 标记为组合键点击
            document.body.setAttribute('data-modifier-key', 'true');
        }
    });

    document.addEventListener('keyup', function(event) {
        document.body.removeAttribute('data-modifier-key');
    });

    console.log('✅ VSCode URL Interceptor: 事件监听器已注册');
}

// 立即注册事件监听器
registerEventListeners();

// 检查URL参数中的VSCode链接
function checkUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    const redirectUri = urlParams.get('redirect_uri');

    if (redirectUri) {
        const decodedUri = decodeURIComponent(redirectUri);
        console.log('🔍 检查URL参数中的redirect_uri:', decodedUri);

        if (decodedUri.startsWith('vscode://') || decodedUri.startsWith('vscode-insiders://')) {
            console.log('🎯 在URL参数中发现VSCode协议链接!', decodedUri);
            return decodedUri;
        }
    }

    return null;
}

// 扫描页面中的VSCode链接
function scanVSCodeLinks() {
    const allLinks = document.querySelectorAll('a[href]');
    const vscodeLinks = [];
    const allHrefs = [];

    allLinks.forEach(link => {
        allHrefs.push(link.href);
        if (link.href.startsWith('vscode://') || link.href.startsWith('vscode-insiders://')) {
            vscodeLinks.push(link.href);
        }
    });

    // 检查URL参数
    const urlParamVscode = checkUrlParameters();
    if (urlParamVscode) {
        vscodeLinks.push(urlParamVscode);
    }

    console.log('🔍 扫描结果:', {
        总链接数: allLinks.length,
        VSCode链接数: vscodeLinks.length,
        VSCode链接: vscodeLinks,
        URL参数中的VSCode链接: urlParamVscode,
        所有链接前10个: allHrefs.slice(0, 10)
    });

    return vscodeLinks;
}

// 定期扫描VSCode链接
function startPeriodicScan() {
    setInterval(() => {
        console.log('⏰ 定期扫描VSCode链接...');
        scanVSCodeLinks();
    }, 5000); // 每5秒扫描一次

    console.log('⏰ 定期扫描已启动 (每5秒)');
}

// 监听DOM变化，检测动态添加的链接
function observeDOM() {
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        // 检查新添加的元素是否包含VSCode链接
                        const links = node.querySelectorAll ? node.querySelectorAll('a[href^="vscode://"], a[href^="vscode-insiders://"]') : [];
                        if (links.length > 0) {
                            console.log('VSCode URL Interceptor: 检测到动态添加的VSCode链接:', Array.from(links).map(l => l.href));
                        }
                    }
                });
            }
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    console.log('VSCode URL Interceptor: DOM观察器已启动');
}

// 页面加载完成后的初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        console.log('✅ VSCode URL Interceptor 初始化完成');
        console.log('🌐 当前页面URL:', window.location.href);
        console.log('⚙️ 插件配置:', config);
        setTimeout(scanVSCodeLinks, 1000); // 延迟1秒扫描，等待动态内容加载
        setTimeout(startPeriodicScan, 2000); // 延迟2秒启动定期扫描
        observeDOM(); // 启动DOM观察器
    });
} else {
    console.log('✅ VSCode URL Interceptor 初始化完成');
    console.log('🌐 当前页面URL:', window.location.href);
    console.log('⚙️ 插件配置:', config);
    setTimeout(scanVSCodeLinks, 1000);
    setTimeout(startPeriodicScan, 2000);
    observeDOM(); // 启动DOM观察器
}

})(); // 结束IIFE闭包
