// VSCode URL Interceptor Background Script
console.log('VSCode URL Interceptor 后台脚本已启动');

// 统计数据
let stats = {
    totalIntercepted: 0,
    successfulCopies: 0,
    lastIntercepted: null
};

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'URL_INTERCEPTED') {
        stats.totalIntercepted++;
        if (message.success) {
            stats.successfulCopies++;
        }
        stats.lastIntercepted = {
            url: message.url,
            timestamp: Date.now(),
            success: message.success,
            tabId: sender.tab?.id
        };
        
        // 保存统计数据
        chrome.storage.local.set({ stats });
        
        console.log('URL拦截统计:', stats);
        sendResponse({ received: true });
    }
});

// 插件安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('VSCode URL Interceptor 首次安装');
        
        // 设置默认配置
        const defaultConfig = {
            enabled: true,
            showNotification: true,
            customPrefix: '>Developer: Open URL',
            interceptProtocols: ['vscode://', 'vscode-insiders://'],
            useOpenUrlCommand: true
        };
        
        chrome.storage.sync.set({ config: defaultConfig });
        chrome.storage.local.set({ stats });
    } else if (details.reason === 'update') {
        console.log('VSCode URL Interceptor 已更新到版本:', chrome.runtime.getManifest().version);
    }
});

// 处理插件图标点击
chrome.action.onClicked.addListener((tab) => {
    // 这里可以添加点击插件图标的处理逻辑
    console.log('插件图标被点击，当前标签页:', tab.url);
});

// 定期清理旧的统计数据（可选）
setInterval(() => {
    chrome.storage.local.get(['stats'], (result) => {
        if (result.stats && result.stats.lastIntercepted) {
            const dayAgo = Date.now() - (24 * 60 * 60 * 1000);
            if (result.stats.lastIntercepted.timestamp < dayAgo) {
                // 可以在这里添加清理逻辑
                console.log('统计数据清理检查');
            }
        }
    });
}, 60 * 60 * 1000); // 每小时检查一次
