# VSCode URL Interceptor

一个强大的 Chrome/Edge 浏览器插件，用于拦截 VSCode 协议链接并格式化复制到剪贴板。

## 🚀 功能特点

- ✅ **智能拦截**: 自动识别并拦截 `vscode://` 和 `vscode-insiders://` 协议链接
- ✅ **格式化复制**: 将链接格式化为 `>developer copy url <原始链接>` 格式
- ✅ **实时通知**: 操作成功后显示友好的通知提示
- ✅ **灵活配置**: 支持自定义前缀、开关通知等设置
- ✅ **使用统计**: 记录拦截次数和成功率
- ✅ **跨平台支持**: 兼容 Chrome 和 Edge 浏览器

## 📦 安装方法

### 方法一：开发者模式安装（推荐）

1. **下载插件文件**
   - 下载整个 `vscode-url-interceptor` 文件夹到本地

2. **准备图标文件**
   - 在 `icons` 文件夹中添加以下尺寸的 PNG 图标：
     - `icon16.png` (16x16)
     - `icon32.png` (32x32) 
     - `icon48.png` (48x48)
     - `icon128.png` (128x128)

3. **安装到浏览器**
   - 打开 Chrome/Edge 浏览器
   - 访问 `chrome://extensions/` (Chrome) 或 `edge://extensions/` (Edge)
   - 开启右上角的"开发者模式"
   - 点击"加载已解压的扩展程序"
   - 选择 `vscode-url-interceptor` 文件夹

### 方法二：打包安装

1. 将插件文件夹打包为 `.zip` 文件
2. 在扩展管理页面选择"加载已解压的扩展程序"
3. 选择解压后的文件夹

## 🎯 使用方法

1. **基本使用**
   - 在任何网页上点击 `vscode://` 协议链接
   - 插件会自动拦截并阻止 VSCode 启动
   - 格式化后的链接会自动复制到剪贴板
   - 右上角显示成功通知

2. **设置配置**
   - 点击浏览器工具栏中的插件图标
   - 在弹出窗口中调整设置：
     - 启用/禁用拦截功能
     - 开关通知显示
     - 自定义复制前缀
   - 查看使用统计信息

3. **格式化示例**
   ```
   原始链接: vscode://augment.vscode-augment/auth/result?code=_8153a9b53ef433540ea1e2d36c28ff64&state=6d809774-30d3-4700-888a-5ef168da7b44&tenant_url=https%3A%2F%2Fd17.api.augmentcode.com%2F

   格式化为VSCode命令:
   >Developer: Open URL
   vscode://augment.vscode-augment/auth/result?code=_8153a9b53ef433540ea1e2d36c28ff64&state=6d809774-30d3-4700-888a-5ef168da7b44&tenant_url=https%3A%2F%2Fd17.api.augmentcode.com%2F
   ```

4. **VSCode中使用方法**
   - 在VSCode中按 `Ctrl+Shift+P` (Windows/Linux) 或 `Cmd+Shift+P` (Mac)
   - 粘贴复制的命令并按回车执行
   - VSCode会自动处理认证链接

## ⚙️ 配置选项

| 选项 | 说明 | 默认值 |
|------|------|--------|
| 启用拦截 | 是否拦截 VSCode 协议链接 | ✅ 启用 |
| 显示通知 | 操作后是否显示通知 | ✅ 启用 |
| 使用VSCode命令格式 | 格式化为可直接在VSCode命令面板使用的格式 | ✅ 启用 |
| 自定义前缀 | 复制时的命令名称 | `>Developer: Open URL` |
| 支持协议 | 拦截的协议类型 | `vscode://`, `vscode-insiders://` |

## 🔧 技术实现

- **Manifest V3**: 使用最新的扩展 API
- **Content Script**: 页面内容脚本处理链接拦截
- **Background Script**: 后台脚本处理统计和配置
- **Storage API**: 同步保存用户配置和统计数据
- **Clipboard API**: 安全的剪贴板操作

## 📊 权限说明

| 权限 | 用途 |
|------|------|
| `clipboardWrite` | 复制格式化链接到剪贴板 |
| `activeTab` | 访问当前标签页内容 |
| `scripting` | 注入内容脚本 |
| `storage` | 保存用户配置和统计数据 |
| `<all_urls>` | 在所有网站上拦截协议链接 |

## 🐛 故障排除

### 常见问题

1. **插件无法加载**
   - 确保所有文件都在正确位置
   - 检查 `manifest.json` 语法是否正确
   - 确保图标文件存在且格式正确

2. **拦截不生效**
   - 检查插件是否已启用
   - 确认在设置中开启了拦截功能
   - 刷新页面后重试

3. **复制失败**
   - 检查浏览器是否允许剪贴板访问
   - 确保网站使用 HTTPS 协议
   - 尝试手动授予剪贴板权限

### 调试方法

1. 打开浏览器开发者工具 (F12)
2. 查看 Console 标签页的错误信息
3. 检查插件的后台页面日志

## 🔄 更新日志

### v1.0.0 (2024-08-09)
- ✨ 初始版本发布
- ✅ 基本拦截功能
- ✅ 格式化复制功能
- ✅ 配置界面
- ✅ 使用统计
- ✅ 通知系统

## 📝 开发说明

### 文件结构
```
vscode-url-interceptor/
├── manifest.json          # 插件配置文件
├── content.js             # 内容脚本
├── background.js          # 后台脚本
├── popup.html            # 弹出窗口界面
├── popup.js              # 弹出窗口逻辑
├── welcome.html          # 欢迎页面
├── icons/                # 图标文件夹
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── README.md             # 说明文档
```

### 开发环境
- Chrome/Edge 浏览器
- 文本编辑器
- 基本的 HTML/CSS/JavaScript 知识

## 📄 许可证

MIT License - 详见 LICENSE 文件

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📞 支持

如有问题或建议，请通过以下方式联系：
- 提交 GitHub Issue
- 发送邮件反馈

---

**享受更高效的开发体验！** 🎉
