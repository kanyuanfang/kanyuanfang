// Popup Script for VSCode URL Interceptor
document.addEventListener('DOMContentLoaded', async () => {
    const enabledToggle = document.getElementById('enabledToggle');
    const notificationToggle = document.getElementById('notificationToggle');
    const useCommandToggle = document.getElementById('useCommandToggle');
    const prefixInput = document.getElementById('prefixInput');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');
    const statusDiv = document.getElementById('status');
    const statusText = document.getElementById('statusText');
    const totalCount = document.getElementById('totalCount');
    const successCount = document.getElementById('successCount');
    const lastTime = document.getElementById('lastTime');

    // 默认配置
    const defaultConfig = {
        enabled: true,
        showNotification: true,
        customPrefix: '>Developer: Open URL',
        interceptProtocols: ['vscode://', 'vscode-insiders://'],
        useOpenUrlCommand: true
    };

    // 加载配置
    async function loadConfig() {
        try {
            const result = await chrome.storage.sync.get(['config']);
            const config = result.config || defaultConfig;
            
            enabledToggle.checked = config.enabled;
            notificationToggle.checked = config.showNotification;
            useCommandToggle.checked = config.useOpenUrlCommand !== false;
            prefixInput.value = config.customPrefix;
            
            updateStatus(config.enabled);
            return config;
        } catch (error) {
            console.error('加载配置失败:', error);
            showMessage('加载配置失败', 'error');
            return defaultConfig;
        }
    }

    // 加载统计数据
    async function loadStats() {
        try {
            const result = await chrome.storage.local.get(['stats']);
            const stats = result.stats || { totalIntercepted: 0, successfulCopies: 0, lastIntercepted: null };
            
            totalCount.textContent = stats.totalIntercepted;
            successCount.textContent = stats.successfulCopies;
            
            if (stats.lastIntercepted) {
                const date = new Date(stats.lastIntercepted.timestamp);
                lastTime.textContent = date.toLocaleString('zh-CN');
            } else {
                lastTime.textContent = '无';
            }
        } catch (error) {
            console.error('加载统计数据失败:', error);
        }
    }

    // 保存配置
    async function saveConfig() {
        const config = {
            enabled: enabledToggle.checked,
            showNotification: notificationToggle.checked,
            useOpenUrlCommand: useCommandToggle.checked,
            customPrefix: prefixInput.value.trim() || defaultConfig.customPrefix,
            interceptProtocols: defaultConfig.interceptProtocols
        };

        try {
            await chrome.storage.sync.set({ config });
            updateStatus(config.enabled);
            showMessage('设置已保存', 'success');
            
            // 通知所有标签页配置已更新
            const tabs = await chrome.tabs.query({});
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { type: 'CONFIG_UPDATED', config }).catch(() => {
                    // 忽略无法发送消息的标签页
                });
            });
        } catch (error) {
            console.error('保存配置失败:', error);
            showMessage('保存失败', 'error');
        }
    }

    // 重置配置
    async function resetConfig() {
        if (confirm('确定要重置所有设置吗？')) {
            try {
                await chrome.storage.sync.set({ config: defaultConfig });
                await loadConfig();
                showMessage('设置已重置', 'success');
            } catch (error) {
                console.error('重置配置失败:', error);
                showMessage('重置失败', 'error');
            }
        }
    }

    // 更新状态显示
    function updateStatus(enabled) {
        if (enabled) {
            statusDiv.className = 'status enabled';
            statusText.textContent = '✅ 拦截功能已启用';
        } else {
            statusDiv.className = 'status disabled';
            statusText.textContent = '❌ 拦截功能已禁用';
        }
    }

    // 显示消息
    function showMessage(message, type = 'success') {
        const originalText = statusText.textContent;
        const originalClass = statusDiv.className;
        
        statusDiv.className = `status ${type === 'success' ? 'enabled' : 'disabled'}`;
        statusText.textContent = message;
        
        setTimeout(() => {
            statusDiv.className = originalClass;
            statusText.textContent = originalText;
        }, 2000);
    }

    // 验证输入
    function validateInput() {
        const prefix = prefixInput.value.trim();
        if (prefix.length === 0) {
            prefixInput.value = defaultConfig.customPrefix;
        }
    }

    // 事件监听器
    saveBtn.addEventListener('click', saveConfig);
    resetBtn.addEventListener('click', resetConfig);
    
    // 实时保存开关状态
    enabledToggle.addEventListener('change', saveConfig);
    notificationToggle.addEventListener('change', saveConfig);
    useCommandToggle.addEventListener('change', saveConfig);
    
    // 输入验证
    prefixInput.addEventListener('blur', validateInput);
    
    // 回车键保存
    prefixInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            saveConfig();
        }
    });

    // 初始化
    await loadConfig();
    await loadStats();
    
    // 定期更新统计数据
    setInterval(loadStats, 5000);
});
